plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.pagereader"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.pagereader"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // Cloud AI Key
        buildConfigField("String", "GEMINI_API_KEY", "\"AQ.Ab8RN6LXee2ZBHx3yZLWS42H4Krph_miZieMDkSLuyNyW3EjWg\"")

        // Google Credential Manager Web Client ID
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"242885905058-3ofd4d3k467td5h9reamde1tcjkoftq3.apps.googleusercontent.com\"")
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    // CameraX
    val cameraxVersion = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    // Cloud Multimodal AI: Google GenAI Client
    implementation("com.google.ai.client.generativeai:generativeai:0.9.0")

    // Offline Local Fallback: ML Kit Text Recognition
    implementation("com.google.android.gms:play-services-mlkit-text-recognition:19.0.0")

    // Sign in with Google (Android Credential Manager)
    implementation("androidx.credentials:credentials:1.5.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.5.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Google Play Billing (Subscriptions)
    implementation("com.android.billingclient:billing-ktx:7.1.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
