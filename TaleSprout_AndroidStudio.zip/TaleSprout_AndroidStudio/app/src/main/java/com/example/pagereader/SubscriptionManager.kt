package com.example.pagereader

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class SubscriptionTier(
    val productId: String,
    val displayName: String,
    val maxProfiles: Int,
    val allowsCloudAi: Boolean
) {
    FREE_OFFLINE(
        productId = "free_offline",
        displayName = "Free Reader (Offline)",
        maxProfiles = 1,
        allowsCloudAi = false
    ),
    INDIVIDUAL_PRO(
        productId = "storyteller_individual_unlimited",
        displayName = "Individual Pro (1 Profile + Unlimited Cloud AI)",
        maxProfiles = 1,
        allowsCloudAi = true
    ),
    FAMILY_PRO(
        productId = "storyteller_family_unlimited",
        displayName = "Family Plan (Up to 5 Profiles + Unlimited Cloud AI)",
        maxProfiles = 5,
        allowsCloudAi = true
    )
}

class SubscriptionManager(private val context: Context) : PurchasesUpdatedListener {

    private val prefs = context.getSharedPreferences("subscription_prefs", Context.MODE_PRIVATE)

    private val _currentTier = MutableStateFlow(loadCachedTier())
    val currentTier: StateFlow<SubscriptionTier> = _currentTier

    val maxAllowedProfiles: Int
        get() = _currentTier.value.maxProfiles

    val hasCloudAiAccess: Boolean
        get() = _currentTier.value.allowsCloudAi

    private val billingClient: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    private fun loadCachedTier(): SubscriptionTier {
        val savedName = prefs.getString("cached_tier", SubscriptionTier.FREE_OFFLINE.name)
        return try {
            SubscriptionTier.valueOf(savedName ?: SubscriptionTier.FREE_OFFLINE.name)
        } catch (e: Exception) {
            SubscriptionTier.FREE_OFFLINE
        }
    }

    fun startConnection(onReady: () -> Unit = {}) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    refreshPurchases()
                    onReady()
                }
            }

            override fun onBillingServiceDisconnected() {
                // Retry on next foreground resume
            }
        })
    }

    fun refreshPurchases() {
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        billingClient.queryPurchasesAsync(params) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                val activePurchases = purchases.filter {
                    it.purchaseState == Purchase.PurchaseState.PURCHASED
                }

                val resolvedTier = when {
                    activePurchases.any { it.products.contains(SubscriptionTier.FAMILY_PRO.productId) } ->
                        SubscriptionTier.FAMILY_PRO
                    activePurchases.any { it.products.contains(SubscriptionTier.INDIVIDUAL_PRO.productId) } ->
                        SubscriptionTier.INDIVIDUAL_PRO
                    else -> SubscriptionTier.FREE_OFFLINE
                }

                updateTier(resolvedTier)

                activePurchases.filter { !it.isAcknowledged }.forEach { purchase ->
                    val ackParams = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken)
                        .build()
                    billingClient.acknowledgePurchase(ackParams) { }
                }
            }
        }
    }

    fun launchSubscriptionFlow(activity: Activity, targetTier: SubscriptionTier) {
        if (targetTier == SubscriptionTier.FREE_OFFLINE) return

        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(targetTier.productId)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )
        val params = QueryProductDetailsParams.newBuilder().setProductList(productList).build()

        billingClient.queryProductDetailsAsync(params) { _, productDetailsList ->
            val details = productDetailsList.firstOrNull() ?: return@queryProductDetailsAsync
            val offerToken = details.subscriptionOfferDetails?.firstOrNull()?.offerToken ?: return@queryProductDetailsAsync

            val flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(
                    listOf(
                        BillingFlowParams.ProductDetailsParams.newBuilder()
                            .setProductDetails(details)
                            .setOfferToken(offerToken)
                            .build()
                    )
                )
                .build()

            billingClient.launchBillingFlow(activity, flowParams)
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            refreshPurchases()
        }
    }

    private fun updateTier(tier: SubscriptionTier) {
        _currentTier.value = tier
        prefs.edit().putString("cached_tier", tier.name).apply()
    }
}
