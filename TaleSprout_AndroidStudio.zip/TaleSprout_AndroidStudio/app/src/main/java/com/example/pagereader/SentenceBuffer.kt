package com.example.pagereader

class SentenceBuffer(
    private val onSentenceReady: (sentence: String, isFirstSentence: Boolean) -> Unit
) {
    private val buffer = StringBuilder()
    private var isFirst = true

    companion object {
        private val SENTENCE_BOUNDARY_REGEX = Regex(
            """(?x)
            (?<= [.!?] | \n )
            (?<! \b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|etc|approx|vol|no|i\.e|e\.g)\. )
            (?<! \b[A-Za-z]\. )
            (?<! \d\. )
            \s+
            (?= [A-Z"“'(\d] | ${'$'} )
            """
        )
    }

    @Synchronized
    fun processChunk(partialToken: String) {
        buffer.append(partialToken)
        val fullText = buffer.toString()
        val parts = fullText.split(SENTENCE_BOUNDARY_REGEX)

        if (parts.size > 1) {
            for (i in 0 until parts.size - 1) {
                val sentence = parts[i].trim()
                if (sentence.isNotEmpty() && !isFalsePositive(sentence)) {
                    onSentenceReady(sentence, isFirst)
                    isFirst = false
                }
            }
            buffer.clear()
            buffer.append(parts.last())
        }
    }

    private fun isFalsePositive(segment: String): Boolean {
        return segment.all { !it.isLetterOrDigit() }
    }

    @Synchronized
    fun flush() {
        val remaining = buffer.toString().trim()
        if (remaining.isNotEmpty()) {
            onSentenceReady(remaining, isFirst)
        }
        buffer.clear()
        isFirst = true
    }

    @Synchronized
    fun reset() {
        buffer.clear()
        isFirst = true
    }
}
