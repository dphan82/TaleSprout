package com.example.pagereader

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlin.math.abs

class PageTurnAnalyzer(
    private val onMotionDeltaUpdate: (Double) -> Unit,
    private val onMotionStarted: () -> Unit,
    private val onSettledSamePage: () -> Unit,
    private val onSettledNewPage: () -> Unit,
    private val getSamePageTolerance: () -> Float = { 14.0f }
) : ImageAnalysis.Analyzer {

    private var previousLumaGrid: IntArray? = null
    private var activePageReferenceGrid: IntArray? = null
    private var isTurnInProgress = false
    private var stableFrameCount = 0

    private val gridSize = 16
    private val motionTriggerThreshold = 22.0
    private val motionQuietThreshold = 7.0
    private val requiredStableFrames = 10

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val yPlane = mediaImage.planes[0]
        val buffer = yPlane.buffer
        val rowStride = yPlane.rowStride
        val width = imageProxy.width
        val height = imageProxy.height

        val currentLumaGrid = IntArray(gridSize * gridSize)
        val stepX = width / gridSize
        val stepY = height / gridSize

        for (gy in 0 until gridSize) {
            for (gx in 0 until gridSize) {
                val index = (gy * stepY * rowStride) + (gx * stepX)
                if (index < buffer.limit()) {
                    currentLumaGrid[gy * gridSize + gx] = buffer.get(index).toInt() and 0xFF
                }
            }
        }

        previousLumaGrid?.let { prev ->
            val frameDelta = calculateGridDiff(currentLumaGrid, prev)
            onMotionDeltaUpdate(frameDelta)

            if (!isTurnInProgress) {
                if (frameDelta > motionTriggerThreshold) {
                    isTurnInProgress = true
                    stableFrameCount = 0
                    onMotionStarted()
                }
            } else {
                if (frameDelta < motionQuietThreshold) {
                    stableFrameCount++
                    if (stableFrameCount >= requiredStableFrames) {
                        isTurnInProgress = false
                        stableFrameCount = 0

                        val refGrid = activePageReferenceGrid
                        if (refGrid != null && calculateGridDiff(currentLumaGrid, refGrid) < getSamePageTolerance()) {
                            onSettledSamePage()
                        } else {
                            activePageReferenceGrid = currentLumaGrid.copyOf()
                            onSettledNewPage()
                        }
                    }
                } else {
                    stableFrameCount = 0
                }
            }
        } ?: run {
            activePageReferenceGrid = currentLumaGrid.copyOf()
        }

        previousLumaGrid = currentLumaGrid
        imageProxy.close()
    }

    private fun calculateGridDiff(gridA: IntArray, gridB: IntArray): Double {
        var totalDelta = 0L
        for (i in gridA.indices) {
            totalDelta += abs(gridA[i] - gridB[i])
        }
        return totalDelta.toDouble() / gridA.size
    }

    fun resetReferencePage() {
        activePageReferenceGrid = null
    }
}
