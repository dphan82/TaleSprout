package com.example.pagereader

import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import org.json.JSONObject

data class GoogleUserAccount(
    val idToken: String,
    val email: String,
    val displayName: String?,
    val profilePictureUrl: String?
) {
    fun toJson(): String {
        val json = JSONObject()
        json.put("idToken", idToken)
        json.put("email", email)
        json.put("displayName", displayName)
        json.put("profilePictureUrl", profilePictureUrl)
        return json.toString()
    }

    companion object {
        fun fromJson(jsonStr: String): GoogleUserAccount {
            val json = JSONObject(jsonStr)
            return GoogleUserAccount(
                idToken = json.getString("idToken"),
                email = json.getString("email"),
                displayName = if (json.isNull("displayName")) null else json.getString("displayName"),
                profilePictureUrl = if (json.isNull("profilePictureUrl")) null else json.getString("profilePictureUrl")
            )
        }
    }
}

class GoogleAuthManager(private val context: Context) {

    private val credentialManager = CredentialManager.create(context)
    private val prefs = context.getSharedPreferences("google_auth_prefs", Context.MODE_PRIVATE)

    private val webClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID

    fun getSignedInUser(): GoogleUserAccount? {
        val raw = prefs.getString("signed_in_user", null) ?: return null
        return try {
            GoogleUserAccount.fromJson(raw)
        } catch (e: Exception) {
            null
        }
    }

    fun isSignedIn(): Boolean = getSignedInUser() != null

    suspend fun signInWithGoogle(activityContext: Context): Result<GoogleUserAccount> {
        return try {
            val credentialResult = try {
                val authorizedOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(true)
                    .setServerClientId(webClientId)
                    .setAutoSelectEnabled(true)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(authorizedOption)
                    .build()

                credentialManager.getCredential(request = request, context = activityContext)
            } catch (e: NoCredentialException) {
                val allAccountsOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(webClientId)
                    .build()

                val fallbackRequest = GetCredentialRequest.Builder()
                    .addCredentialOption(allAccountsOption)
                    .build()

                credentialManager.getCredential(request = fallbackRequest, context = activityContext)
            }

            val credential = credentialResult.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val user = GoogleUserAccount(
                    idToken = googleIdTokenCredential.idToken,
                    email = googleIdTokenCredential.id,
                    displayName = googleIdTokenCredential.displayName,
                    profilePictureUrl = googleIdTokenCredential.profilePictureUri?.toString()
                )
                saveSignedInUser(user)
                Result.success(user)
            } else {
                Result.failure(IllegalStateException("Unexpected credential type returned"))
            }
        } catch (e: GoogleIdTokenParsingException) {
            Log.e("GoogleAuth", "Invalid Google ID Token response", e)
            Result.failure(e)
        } catch (e: GetCredentialException) {
            Log.w("GoogleAuth", "Sign-in cancelled or failed: ${e.message}")
            Result.failure(e)
        } catch (e: Exception) {
            Log.e("GoogleAuth", "Unexpected auth error", e)
            Result.failure(e)
        }
    }

    suspend fun signOut() {
        prefs.edit().remove("signed_in_user").apply()
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.w("GoogleAuth", "Failed to clear credential state", e)
        }
    }

    private fun saveSignedInUser(user: GoogleUserAccount) {
        prefs.edit().putString("signed_in_user", user.toJson()).apply()
    }
}
