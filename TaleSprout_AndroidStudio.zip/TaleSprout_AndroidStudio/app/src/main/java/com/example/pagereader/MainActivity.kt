package com.example.pagereader

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.util.Size
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.pagereader.databinding.ActivityMainElementaryKidsBinding
import com.example.pagereader.databinding.DialogAccountAndPlansBinding
import com.example.pagereader.databinding.DialogReaderSettingsBinding
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainElementaryKidsBinding
    private lateinit var cameraExecutor: ExecutorService
    private var imageCapture: ImageCapture? = null
    private var tts: TextToSpeech? = null
    private var isProcessingCapture = false
    private var lastSpokenText = ""

    // Core Managers
    private lateinit var profileManager: ReaderProfileManager
    private lateinit var currentProfile: ReaderProfile
    private lateinit var subscriptionManager: SubscriptionManager
    private lateinit var bookSessionManager: BookSessionManager
    private lateinit var googleAuthManager: GoogleAuthManager

    // Sentence-indexed playback & pause/resume tracking
    private var currentPageSentences: List<String> = emptyList()
    private var currentSentenceIndex: Int = 0
    private var isPausedByMotion: Boolean = false
    private val toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 60)

    private val supportedLocales = listOf(
        Locale.US,
        Locale.UK,
        Locale.forLanguageTag("es-ES"),
        Locale.forLanguageTag("fr-FR"),
        Locale.forLanguageTag("de-DE"),
        Locale.forLanguageTag("vi-VN"),
        Locale.JAPAN
    )

    private val cloudAiModel by lazy {
        GenerativeModel(
            modelName = "gemini-2.0-flash",
            apiKey = BuildConfig.GEMINI_API_KEY
        )
    }

    private val offlineRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) startCamera() else binding.tvState.text = "📷 Please allow camera access!"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding = ActivityMainElementaryKidsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileManager = ReaderProfileManager(this)
        currentProfile = profileManager.getActiveProfile()
        subscriptionManager = SubscriptionManager(this).apply { startConnection() }
        bookSessionManager = BookSessionManager(this)
        googleAuthManager = GoogleAuthManager(this)

        tts = TextToSpeech(this, this)
        cameraExecutor = Executors.newSingleThreadExecutor()

        updateProfileHeaderPill()

        // Top-left Reader Pill & Top-right Account button (Zero parental lock)
        binding.btnReaderProfilePill.setOnClickListener {
            showReaderSettingsDialog()
        }
        binding.btnSettings.setOnClickListener {
            showAccountAndPlanDialog()
        }

        // Kid-friendly bottom card action buttons
        binding.btnReadAgain.setOnClickListener {
            if (currentPageSentences.isNotEmpty()) {
                isPausedByMotion = false
                binding.tvState.text = "🔁 Reading Again!"
                binding.tvState.setTextColor(0xFF2E7D32.toInt())
                speakFromSentenceIndex(0)
            }
        }

        binding.btnFinishBook.setOnClickListener {
            tts?.stop()
            currentPageSentences = emptyList()
            currentSentenceIndex = 0
            isPausedByMotion = false
            bookSessionManager.finishCurrentBook()
            binding.tvState.text = "⭐ Great Job Finishing Your Book!"
            binding.tvState.setTextColor(0xFF2E7D32.toInt())
            Toast.makeText(this, "Book finished! Ready for your next story.", Toast.LENGTH_SHORT).show()
        }

        // Tap status card to resume when in PAUSE_MANUAL_RESUME mode
        binding.statusCard.setOnClickListener {
            if (isPausedByMotion && currentPageSentences.isNotEmpty()) {
                isPausedByMotion = false
                binding.tvState.text = "✨ Reading Story!"
                binding.tvState.setTextColor(0xFF2E7D32.toInt())
                speakFromSentenceIndex(currentSentenceIndex)
            }
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        subscriptionManager.refreshPurchases()
    }

    private fun updateProfileHeaderPill() {
        binding.btnReaderProfilePill.text = "${currentProfile.avatarEmoji} ${currentProfile.name}  ▾"
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            applyProfileVoice(currentProfile)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    if (utteranceId != null && utteranceId.startsWith("SENTENCE_")) {
                        val idx = utteranceId.removePrefix("SENTENCE_").toIntOrNull()
                        if (idx != null) currentSentenceIndex = idx
                    }
                }

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "SENTENCE_${currentPageSentences.lastIndex}") {
                        runOnUiThread {
                            binding.tvState.text = "📖 Turn the page for more!"
                            binding.tvState.setTextColor(0xFF2E7D32.toInt())
                            currentPageSentences = emptyList()
                            currentSentenceIndex = 0
                        }
                    }
                }

                override fun onError(utteranceId: String?) {}
            })
        }
    }

    private fun applyProfileVoice(profile: ReaderProfile) {
        val engine = tts ?: return
        val targetLocale = Locale.forLanguageTag(profile.languageTag)
        engine.language = targetLocale

        if (profile.voiceName != null) {
            val match = engine.voices?.find { it.name == profile.voiceName }
            if (match != null) engine.voice = match
        }

        engine.setPitch(profile.effectivePitch)
        engine.setSpeechRate(profile.effectiveSpeed)
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.viewFinder.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val imageAnalyzer = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 360))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, PageTurnAnalyzer(
                        onMotionDeltaUpdate = { delta ->
                            runOnUiThread { binding.tvMotionDelta.text = "Δ: ${"%.1f".format(delta)}" }
                        },
                        onMotionStarted = {
                            runOnUiThread {
                                val wasReading = currentPageSentences.isNotEmpty()
                                tts?.stop()

                                if (wasReading) {
                                    isPausedByMotion = true
                                    if (currentProfile.playPauseWarningChime) {
                                        toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                                    }
                                    binding.tvState.text = when (currentProfile.interruptionMode) {
                                        InterruptionMode.SMART_AUTO_RESUME -> "🦉 Paused — Hold still to keep reading!"
                                        InterruptionMode.PAUSE_MANUAL_RESUME -> "👆 Paused — Tap card to continue!"
                                        InterruptionMode.STRICT_RESCAN -> "📖 Turning page..."
                                    }
                                    binding.tvState.setTextColor(0xFFE65100.toInt())
                                } else {
                                    binding.tvState.text = "📖 Turning page..."
                                    binding.tvState.setTextColor(0xFFE65100.toInt())
                                }
                            }
                        },
                        onSettledSamePage = {
                            runOnUiThread {
                                if (!isPausedByMotion || currentPageSentences.isEmpty()) {
                                    binding.tvState.text = "🦉 Ready for Storytime!"
                                    binding.tvState.setTextColor(0xFF2E7D32.toInt())
                                    return@runOnUiThread
                                }

                                when (currentProfile.interruptionMode) {
                                    InterruptionMode.SMART_AUTO_RESUME -> {
                                        isPausedByMotion = false
                                        binding.tvState.text = "✨ Continuing Your Story!"
                                        binding.tvState.setTextColor(0xFF2E7D32.toInt())
                                        speakFromSentenceIndex(currentSentenceIndex)
                                    }
                                    InterruptionMode.PAUSE_MANUAL_RESUME -> {
                                        binding.tvState.text = "👆 Paused — Tap here to keep reading!"
                                    }
                                    InterruptionMode.STRICT_RESCAN -> {
                                        isPausedByMotion = false
                                        currentPageSentences = emptyList()
                                        currentSentenceIndex = 0
                                        if (!isProcessingCapture) triggerCaptureAndProcess()
                                    }
                                }
                            }
                        },
                        onSettledNewPage = {
                            runOnUiThread {
                                isPausedByMotion = false
                                currentPageSentences = emptyList()
                                currentSentenceIndex = 0
                                if (!isProcessingCapture) {
                                    binding.tvState.text = "🔍 Looking at new page..."
                                    binding.tvState.setTextColor(0xFF1565C0.toInt())
                                    triggerCaptureAndProcess()
                                }
                            }
                        },
                        getSamePageTolerance = { currentProfile.samePageTolerance }
                    ))
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture, imageAnalyzer)
            } catch (exc: Exception) {
                Log.e("PageReader", "Binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun triggerCaptureAndProcess() {
        val capture = imageCapture ?: return
        isProcessingCapture = true

        // Enforce Free Tier limit (1 book or 25 pages max per day) vs Unlimited Pro/Family
        when (val status = bookSessionManager.recordPageAndVerifyAccess(subscriptionManager.hasCloudAiAccess)) {
            is BookSessionStatus.Allowed -> {
                // Proceed to capture
            }
            is BookSessionStatus.DailyLimitReached -> {
                runOnUiThread {
                    isProcessingCapture = false
                    binding.tvState.text = when (status.reason) {
                        LimitReason.BOOK_LIMIT_REACHED -> "⭐ 1 Free Book Finished Today!"
                        LimitReason.PAGE_CAP_REACHED -> "⭐ 25 Free Pages Reached Today!"
                    }
                    binding.tvState.setTextColor(0xFFE65100.toInt())
                    showAccountAndPlanDialog()
                }
                return
            }
        }

        capture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                @OptIn(ExperimentalGetImage::class)
                override fun onCaptureSuccess(imageProxy: ImageProxy) {
                    val bitmap = imageProxy.toBitmap()
                    val rotationDegrees = imageProxy.imageInfo.rotationDegrees
                    imageProxy.close()

                    lifecycleScope.launch(Dispatchers.IO) {
                        val useCloudAi = NetworkUtils.isOnline(this@MainActivity) &&
                            subscriptionManager.hasCloudAiAccess

                        if (useCloudAi) {
                            processWithCloudAI(bitmap)
                        } else {
                            processWithOfflineFallback(bitmap, rotationDegrees)
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    isProcessingCapture = false
                }
            }
        )
    }

    private suspend fun processWithCloudAI(bitmap: Bitmap) {
        withContext(Dispatchers.Main) {
            binding.tvState.text = "✨ Reading with Story AI..."
            binding.tvState.setTextColor(0xFF1565C0.toInt())
        }

        try {
            val targetLang = Locale.forLanguageTag(currentProfile.languageTag).displayLanguage
            val prompt = """
                You are a warm, expressive children's book narrator reading aloud in $targetLang.
                1. Inspect the photograph of the open book.
                2. If it is a two-page spread, transcribe the LEFT page top-to-bottom first, then the RIGHT page.
                3. Omit running headers, page numbers, footnotes, and margins.
                4. Reconnect hyphenated words split across lines.
                5. Output ONLY speech-ready narration text in $targetLang with no markdown, title quotes, or preamble.
            """.trimIndent()

            val response = cloudAiModel.generateContent(
                content {
                    image(bitmap)
                    text(prompt)
                }
            )

            val text = response.text?.trim() ?: ""
            dispatchSpeech(text, "Story AI")
        } catch (e: Exception) {
            Log.w("PageReader", "Cloud processing failed, falling back to local OCR", e)
            processWithOfflineFallback(bitmap, 0)
        }
    }

    private fun processWithOfflineFallback(bitmap: Bitmap, rotationDegrees: Int) {
        runOnUiThread {
            binding.tvState.text = "📖 Reading Page..."
            binding.tvState.setTextColor(0xFF2E7D32.toInt())
        }

        val inputImage = InputImage.fromBitmap(bitmap, rotationDegrees)
        offlineRecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val orderedText = sortBlocksTwoPageSpread(visionText, bitmap.width, bitmap.height)
                dispatchSpeech(orderedText, "Offline")
            }
            .addOnFailureListener {
                runOnUiThread {
                    binding.tvState.text = "🤔 Couldn't see the words—try again!"
                    isProcessingCapture = false
                }
            }
    }

    private fun sortBlocksTwoPageSpread(visionText: Text, imgWidth: Int, imgHeight: Int): String {
        val topMargin = imgHeight * 0.05
        val bottomMargin = imgHeight * 0.95
        val contentBlocks = visionText.textBlocks.filter {
            val box = it.boundingBox ?: return@filter false
            box.top > topMargin && box.bottom < bottomMargin
        }

        val midpointX = imgWidth / 2
        val leftPage = mutableListOf<Text.TextBlock>()
        val rightPage = mutableListOf<Text.TextBlock>()

        for (block in contentBlocks) {
            val box = block.boundingBox ?: continue
            if (box.centerX() < midpointX) leftPage.add(block) else rightPage.add(block)
        }

        leftPage.sortBy { it.boundingBox?.top ?: 0 }
        rightPage.sortBy { it.boundingBox?.top ?: 0 }

        return (leftPage + rightPage).joinToString("\n") { it.text }
            .replace("-\n", "")
            .replace("\n", " ")
            .trim()
    }

    private fun dispatchSpeech(cleanedText: String, source: String) {
        runOnUiThread {
            if (cleanedText.length < 20) {
                binding.tvState.text = "🦉 No words found on this page"
                isProcessingCapture = false
                return@runOnUiThread
            }

            if (isDuplicateContent(cleanedText, lastSpokenText) &&
                currentProfile.interruptionMode != InterruptionMode.STRICT_RESCAN
            ) {
                binding.tvState.text = "🦉 Same page — ready when you turn!"
                isProcessingCapture = false
                return@runOnUiThread
            }

            lastSpokenText = cleanedText
            val remainingInfo = if (subscriptionManager.hasCloudAiAccess) {
                ""
            } else {
                val left = bookSessionManager.getRemainingPagesToday(false)
                " ($left free pages left today)"
            }

            binding.tvState.text = "✨ Reading Story!$remainingInfo"
            binding.tvState.setTextColor(0xFF2E7D32.toInt())
            binding.tvRecognizedText.text = cleanedText

            queueSentencesForPlayback(cleanedText)
            isProcessingCapture = false
        }
    }

    private fun queueSentencesForPlayback(cleanedText: String) {
        val parsedSentences = mutableListOf<String>()
        val buffer = SentenceBuffer { sentence, _ ->
            parsedSentences.add(sentence)
        }
        buffer.processChunk(cleanedText)
        buffer.flush()

        currentPageSentences = parsedSentences
        currentSentenceIndex = 0
        speakFromSentenceIndex(0)
    }

    private fun speakFromSentenceIndex(startIndex: Int) {
        if (startIndex < 0 || startIndex >= currentPageSentences.size) return

        for (i in startIndex until currentPageSentences.size) {
            val mode = if (i == startIndex) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            tts?.speak(currentPageSentences[i], mode, null, "SENTENCE_$i")
        }
    }

    private fun isDuplicateContent(current: String, last: String): Boolean {
        if (last.isEmpty()) return false
        val cWords = current.lowercase().split("\\s+".toRegex()).toSet()
        val lWords = last.lowercase().split("\\s+".toRegex()).toSet()
        val intersection = cWords.intersect(lWords).size
        val union = cWords.union(lWords).size
        return if (union == 0) false else (intersection.toDouble() / union) > 0.75
    }

    // --- Unified Lock-Free Reader Settings Sheet ---
    private fun showReaderSettingsDialog() {
        val dialog = BottomSheetDialog(this)
        val dBinding = DialogReaderSettingsBinding.inflate(layoutInflater)
        dialog.setContentView(dBinding.root)

        fun renderProfileChips() {
            dBinding.chipGroupProfiles.removeAllViews()
            val allProfiles = profileManager.getAllProfiles()
            val maxAllowed = subscriptionManager.maxAllowedProfiles
            dBinding.tvPlanProfileCounter.text =
                "${allProfiles.size} of $maxAllowed reader slot${if (maxAllowed > 1) "s" else ""} used"

            allProfiles.forEach { profile ->
                val chip = Chip(this).apply {
                    text = "${profile.avatarEmoji} ${profile.name}"
                    isCheckable = true
                    isChecked = (profile.id == currentProfile.id)
                    setOnClickListener {
                        profileManager.setActiveProfileId(profile.id)
                        currentProfile = profile
                        applyProfileVoice(currentProfile)
                        updateProfileHeaderPill()
                        dialog.dismiss()
                        showReaderSettingsDialog()
                    }
                }
                dBinding.chipGroupProfiles.addView(chip)
            }
        }

        renderProfileChips()

        dBinding.etKidName.setText(currentProfile.name)

        val avatarButtonId = when (currentProfile.avatarEmoji) {
            "🦊" -> com.example.pagereader.R.id.btnAvatarFox
            "🦉" -> com.example.pagereader.R.id.btnAvatarOwl
            "🐰" -> com.example.pagereader.R.id.btnAvatarBunny
            "🐲" -> com.example.pagereader.R.id.btnAvatarDragon
            else -> com.example.pagereader.R.id.btnAvatarBear
        }
        dBinding.toggleAvatarPicker.check(avatarButtonId)

        when (currentProfile.selectedPreset) {
            VoicePreset.STORYTELLER -> dBinding.toggleVoicePreset.check(com.example.pagereader.R.id.btnPresetStoryteller)
            VoicePreset.TURTLE -> dBinding.toggleVoicePreset.check(com.example.pagereader.R.id.btnPresetTurtle)
            VoicePreset.BUNNY -> dBinding.toggleVoicePreset.check(com.example.pagereader.R.id.btnPresetBunny)
        }

        val friendlyLanguages = listOf(
            "🇺🇸 English",
            "🇬🇧 English (UK)",
            "🇪🇸 Spanish",
            "🇫🇷 French",
            "🇩🇪 German",
            "🇻🇳 Vietnamese",
            "🇯🇵 Japanese"
        )
        val langAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, friendlyLanguages)
        langAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        dBinding.spinnerKidLanguage.adapter = langAdapter

        val initialLangIdx = supportedLocales.indexOfFirst { it.toLanguageTag() == currentProfile.languageTag }
        if (initialLangIdx >= 0) dBinding.spinnerKidLanguage.setSelection(initialLangIdx)

        when (currentProfile.interruptionMode) {
            InterruptionMode.SMART_AUTO_RESUME -> dBinding.rbSmartAutoResume.isChecked = true
            InterruptionMode.PAUSE_MANUAL_RESUME -> dBinding.rbManualResume.isChecked = true
            InterruptionMode.STRICT_RESCAN -> dBinding.rbStrictRescan.isChecked = true
        }
        dBinding.switchProfileWarningChime.isChecked = currentProfile.playPauseWarningChime

        dBinding.btnAddProfile.setOnClickListener {
            val nextNumber = profileManager.getAllProfiles().size + 1
            val result = profileManager.addProfile(
                newProfile = ReaderProfile(name = "Reader $nextNumber", avatarEmoji = "🦊"),
                maxAllowedBySubscription = subscriptionManager.maxAllowedProfiles
            )
            when (result) {
                is ProfileAddResult.Success -> {
                    currentProfile = result.profile
                    applyProfileVoice(currentProfile)
                    updateProfileHeaderPill()
                    dialog.dismiss()
                    showReaderSettingsDialog()
                }
                is ProfileAddResult.LimitReached -> {
                    dialog.dismiss()
                    showAccountAndPlanDialog()
                }
            }
        }

        dBinding.btnAccountAndPlan.setOnClickListener {
            dialog.dismiss()
            showAccountAndPlanDialog()
        }

        dBinding.btnKidHearSample.setOnClickListener {
            val selectedPreset = when (dBinding.toggleVoicePreset.checkedButtonId) {
                com.example.pagereader.R.id.btnPresetTurtle -> VoicePreset.TURTLE
                com.example.pagereader.R.id.btnPresetBunny -> VoicePreset.BUNNY
                else -> VoicePreset.STORYTELLER
            }
            val chosenLocale = supportedLocales[dBinding.spinnerKidLanguage.selectedItemPosition]
            tts?.language = chosenLocale
            tts?.setPitch(selectedPreset.pitch)
            tts?.setSpeechRate(selectedPreset.speed)

            val readerName = dBinding.etKidName.text.toString().ifBlank { "friend" }
            tts?.speak("Hi $readerName! I'm ready to read stories with you!", TextToSpeech.QUEUE_FLUSH, null, "PREVIEW")
        }

        dBinding.btnKidSave.setOnClickListener {
            val chosenAvatar = when (dBinding.toggleAvatarPicker.checkedButtonId) {
                com.example.pagereader.R.id.btnAvatarFox -> "🦊"
                com.example.pagereader.R.id.btnAvatarOwl -> "🦉"
                com.example.pagereader.R.id.btnAvatarBunny -> "🐰"
                com.example.pagereader.R.id.btnAvatarDragon -> "🐲"
                else -> "🐻"
            }
            val selectedPreset = when (dBinding.toggleVoicePreset.checkedButtonId) {
                com.example.pagereader.R.id.btnPresetTurtle -> VoicePreset.TURTLE
                com.example.pagereader.R.id.btnPresetBunny -> VoicePreset.BUNNY
                else -> VoicePreset.STORYTELLER
            }
            val selectedInterruption = when (dBinding.rgProfileInterruptionMode.checkedRadioButtonId) {
                com.example.pagereader.R.id.rbManualResume -> InterruptionMode.PAUSE_MANUAL_RESUME
                com.example.pagereader.R.id.rbStrictRescan -> InterruptionMode.STRICT_RESCAN
                else -> InterruptionMode.SMART_AUTO_RESUME
            }

            currentProfile.avatarEmoji = chosenAvatar
            currentProfile.name = dBinding.etKidName.text.toString().ifBlank { "Reader 1" }
            currentProfile.selectedPreset = selectedPreset
            currentProfile.languageTag = supportedLocales[dBinding.spinnerKidLanguage.selectedItemPosition].toLanguageTag()
            currentProfile.interruptionMode = selectedInterruption
            currentProfile.playPauseWarningChime = dBinding.switchProfileWarningChime.isChecked

            profileManager.updateProfile(currentProfile)
            applyProfileVoice(currentProfile)
            updateProfileHeaderPill()

            Toast.makeText(this, "${currentProfile.avatarEmoji} ${currentProfile.name} saved!", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    // --- Unified Google Account & Subscription Plans Sheet ---
    private fun showAccountAndPlanDialog() {
        val dialog = BottomSheetDialog(this)
        val aBinding = DialogAccountAndPlansBinding.inflate(layoutInflater)
        dialog.setContentView(aBinding.root)

        fun refreshAccountHeader() {
            val user = googleAuthManager.getSignedInUser()
            val tier = subscriptionManager.currentTier.value
            if (user != null) {
                aBinding.tvGoogleAccountStatus.text = "Signed in as ${user.displayName ?: user.email} (${user.email})"
                aBinding.btnGoogleSignIn.visibility = View.GONE
                aBinding.btnGoogleSignOut.visibility = View.VISIBLE
            } else {
                aBinding.tvGoogleAccountStatus.text = "Not signed in (Sign in to sync profiles across devices)"
                aBinding.btnGoogleSignIn.visibility = View.VISIBLE
                aBinding.btnGoogleSignOut.visibility = View.GONE
            }
            aBinding.tvActiveTierBadge.text = "Current Plan: ${tier.displayName}"
        }

        refreshAccountHeader()

        aBinding.btnGoogleSignIn.setOnClickListener {
            lifecycleScope.launch {
                val result = googleAuthManager.signInWithGoogle(this@MainActivity)
                if (result.isSuccess) {
                    Toast.makeText(this@MainActivity, "Signed in with Google!", Toast.LENGTH_SHORT).show()
                    refreshAccountHeader()
                } else {
                    Toast.makeText(this@MainActivity, "Sign-in cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }

        aBinding.btnGoogleSignOut.setOnClickListener {
            lifecycleScope.launch {
                googleAuthManager.signOut()
                refreshAccountHeader()
                Toast.makeText(this@MainActivity, "Signed out", Toast.LENGTH_SHORT).show()
            }
        }

        aBinding.btnSubscribeIndividual.setOnClickListener {
            subscriptionManager.launchSubscriptionFlow(this, SubscriptionTier.INDIVIDUAL_PRO)
            dialog.dismiss()
        }

        aBinding.btnSubscribeFamily.setOnClickListener {
            subscriptionManager.launchSubscriptionFlow(this, SubscriptionTier.FAMILY_PRO)
            dialog.dismiss()
        }

        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        toneGenerator.release()
        tts?.stop()
        tts?.shutdown()
        cameraExecutor.shutdown()
        offlineRecognizer.close()
    }
}
