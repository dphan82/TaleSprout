package com.example.pagereader

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class VoicePreset(val displayName: String, val pitch: Float, val speed: Float) {
    STORYTELLER("🦉 Story", 1.0f, 0.9f),
    TURTLE("🐢 Slow", 0.95f, 0.75f),
    BUNNY("🐰 Fast", 1.25f, 1.1f)
}

enum class InterruptionMode(val label: String) {
    SMART_AUTO_RESUME("Smart Pause & Auto-Resume"),
    PAUSE_MANUAL_RESUME("Pause & Tap to Resume"),
    STRICT_RESCAN("Always Re-Scan on Settle")
}

data class ReaderProfile(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var avatarEmoji: String = "🐻",
    var languageTag: String = "en-US",
    var selectedPreset: VoicePreset = VoicePreset.STORYTELLER,
    var voiceName: String? = null,
    // Per-profile interruption & reading preferences (no parental lock)
    var interruptionMode: InterruptionMode = InterruptionMode.SMART_AUTO_RESUME,
    var playPauseWarningChime: Boolean = true,
    var samePageTolerance: Float = 14.0f
) {
    val effectivePitch: Float get() = selectedPreset.pitch
    val effectiveSpeed: Float get() = selectedPreset.speed

    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("avatarEmoji", avatarEmoji)
            put("languageTag", languageTag)
            put("selectedPreset", selectedPreset.name)
            put("voiceName", voiceName)
            put("interruptionMode", interruptionMode.name)
            put("playPauseWarningChime", playPauseWarningChime)
            put("samePageTolerance", samePageTolerance.toDouble())
        }
    }

    companion object {
        fun fromJsonObject(json: JSONObject): ReaderProfile {
            return ReaderProfile(
                id = json.getString("id"),
                name = json.getString("name"),
                avatarEmoji = json.optString("avatarEmoji", "🐻"),
                languageTag = json.optString("languageTag", "en-US"),
                selectedPreset = try {
                    VoicePreset.valueOf(json.optString("selectedPreset", VoicePreset.STORYTELLER.name))
                } catch (e: Exception) {
                    VoicePreset.STORYTELLER
                },
                voiceName = if (json.isNull("voiceName")) null else json.getString("voiceName"),
                interruptionMode = try {
                    InterruptionMode.valueOf(json.optString("interruptionMode", InterruptionMode.SMART_AUTO_RESUME.name))
                } catch (e: Exception) {
                    InterruptionMode.SMART_AUTO_RESUME
                },
                playPauseWarningChime = json.optBoolean("playPauseWarningChime", true),
                samePageTolerance = json.optDouble("samePageTolerance", 14.0).toFloat()
            )
        }
    }
}

sealed class ProfileAddResult {
    data class Success(val profile: ReaderProfile) : ProfileAddResult()
    data class LimitReached(val currentCount: Int, val maxAllowed: Int) : ProfileAddResult()
}

class ReaderProfileManager(context: Context) {
    private val prefs = context.getSharedPreferences("reader_profiles_v3", Context.MODE_PRIVATE)

    companion object {
        const val ABSOLUTE_MAX_FAMILY_PROFILES = 5
    }

    fun getAllProfiles(): List<ReaderProfile> {
        val rawArray = prefs.getString("profiles_list", null)
        if (rawArray == null) {
            val defaultProfile = ReaderProfile(
                id = "default_reader_1",
                name = "Reader 1",
                avatarEmoji = "🐻",
                languageTag = "en-US",
                selectedPreset = VoicePreset.STORYTELLER
            )
            saveAllProfiles(listOf(defaultProfile))
            setActiveProfileId(defaultProfile.id)
            return listOf(defaultProfile)
        }

        val jsonArray = JSONArray(rawArray)
        val result = mutableListOf<ReaderProfile>()
        for (i in 0 until jsonArray.length()) {
            result.add(ReaderProfile.fromJsonObject(jsonArray.getJSONObject(i)))
        }
        return result.ifEmpty {
            val fallback = ReaderProfile(id = "default_reader_1", name = "Reader 1")
            saveAllProfiles(listOf(fallback))
            listOf(fallback)
        }
    }

    fun getActiveProfile(): ReaderProfile {
        val all = getAllProfiles()
        val activeId = prefs.getString("active_profile_id", null)
        return all.find { it.id == activeId } ?: all.first()
    }

    fun setActiveProfileId(profileId: String) {
        prefs.edit().putString("active_profile_id", profileId).apply()
    }

    fun addProfile(
        newProfile: ReaderProfile,
        maxAllowedBySubscription: Int
    ): ProfileAddResult {
        val currentList = getAllProfiles().toMutableList()
        val effectiveCap = maxAllowedBySubscription.coerceAtMost(ABSOLUTE_MAX_FAMILY_PROFILES)

        if (currentList.size >= effectiveCap) {
            return ProfileAddResult.LimitReached(currentList.size, effectiveCap)
        }

        currentList.add(newProfile)
        saveAllProfiles(currentList)
        setActiveProfileId(newProfile.id)
        return ProfileAddResult.Success(newProfile)
    }

    fun updateProfile(updated: ReaderProfile) {
        val currentList = getAllProfiles().toMutableList()
        val index = currentList.indexOfFirst { it.id == updated.id }
        if (index >= 0) {
            currentList[index] = updated
            saveAllProfiles(currentList)
        }
    }

    fun deleteProfile(profileId: String): Boolean {
        val currentList = getAllProfiles().toMutableList()
        if (currentList.size <= 1) return false

        val removed = currentList.removeAll { it.id == profileId }
        if (removed) {
            saveAllProfiles(currentList)
            if (prefs.getString("active_profile_id", null) == profileId) {
                setActiveProfileId(currentList.first().id)
            }
        }
        return removed
    }

    private fun saveAllProfiles(profiles: List<ReaderProfile>) {
        val jsonArray = JSONArray()
        profiles.forEach { jsonArray.put(it.toJsonObject()) }
        prefs.edit().putString("profiles_list", jsonArray.toString()).apply()
    }
}
