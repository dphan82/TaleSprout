package com.example.pagereader

import android.content.Context
import java.time.LocalDate
import java.util.UUID

sealed class BookSessionStatus {
    data class Allowed(
        val sessionId: String,
        val isUnlimited: Boolean,
        val pagesUsedToday: Int = 0,
        val maxPagesPerDay: Int = BookSessionManager.FREE_TIER_MAX_PAGES_PER_DAY
    ) : BookSessionStatus()

    data class DailyLimitReached(
        val reason: LimitReason,
        val booksReadToday: Int,
        val pagesReadToday: Int
    ) : BookSessionStatus()
}

enum class LimitReason {
    BOOK_LIMIT_REACHED,
    PAGE_CAP_REACHED
}

class BookSessionManager(context: Context) {

    private val prefs = context.getSharedPreferences("daily_book_limits", Context.MODE_PRIVATE)

    companion object {
        const val FREE_TIER_MAX_BOOKS_PER_DAY = 1
        const val FREE_TIER_MAX_PAGES_PER_DAY = 25
        private const val SESSION_INACTIVITY_TIMEOUT_MS = 20 * 60 * 1000L
    }

    fun recordPageAndVerifyAccess(hasUnlimitedAccess: Boolean): BookSessionStatus {
        if (hasUnlimitedAccess) {
            return BookSessionStatus.Allowed(sessionId = "unlimited_pro", isUnlimited = true)
        }

        val todayKey = LocalDate.now().toString()
        val savedDate = prefs.getString("session_date", null)

        if (savedDate != todayKey) {
            val newSessionId = UUID.randomUUID().toString()
            prefs.edit()
                .putString("session_date", todayKey)
                .putString("active_session_id", newSessionId)
                .putInt("books_started_today", 1)
                .putInt("pages_read_today", 1)
                .putLong("last_page_read_timestamp", System.currentTimeMillis())
                .apply()

            return BookSessionStatus.Allowed(
                sessionId = newSessionId,
                isUnlimited = false,
                pagesUsedToday = 1
            )
        }

        val activeSessionId = prefs.getString("active_session_id", null)
        val booksStartedToday = prefs.getInt("books_started_today", 0)
        val pagesReadToday = prefs.getInt("pages_read_today", 0)
        val lastReadTime = prefs.getLong("last_page_read_timestamp", 0L)
        val elapsedSinceLastPage = System.currentTimeMillis() - lastReadTime

        if (pagesReadToday >= FREE_TIER_MAX_PAGES_PER_DAY) {
            return BookSessionStatus.DailyLimitReached(
                reason = LimitReason.PAGE_CAP_REACHED,
                booksReadToday = booksStartedToday,
                pagesReadToday = pagesReadToday
            )
        }

        if (activeSessionId != null && elapsedSinceLastPage < SESSION_INACTIVITY_TIMEOUT_MS) {
            val updatedPages = pagesReadToday + 1
            prefs.edit()
                .putInt("pages_read_today", updatedPages)
                .putLong("last_page_read_timestamp", System.currentTimeMillis())
                .apply()

            return BookSessionStatus.Allowed(
                sessionId = activeSessionId,
                isUnlimited = false,
                pagesUsedToday = updatedPages
            )
        }

        return if (booksStartedToday < FREE_TIER_MAX_BOOKS_PER_DAY) {
            val newSessionId = UUID.randomUUID().toString()
            val updatedPages = pagesReadToday + 1
            prefs.edit()
                .putString("active_session_id", newSessionId)
                .putInt("books_started_today", booksStartedToday + 1)
                .putInt("pages_read_today", updatedPages)
                .putLong("last_page_read_timestamp", System.currentTimeMillis())
                .apply()

            BookSessionStatus.Allowed(
                sessionId = newSessionId,
                isUnlimited = false,
                pagesUsedToday = updatedPages
            )
        } else {
            BookSessionStatus.DailyLimitReached(
                reason = LimitReason.BOOK_LIMIT_REACHED,
                booksReadToday = booksStartedToday,
                pagesReadToday = pagesReadToday
            )
        }
    }

    fun finishCurrentBook() {
        prefs.edit()
            .remove("active_session_id")
            .putLong("last_page_read_timestamp", 0L)
            .apply()
    }

    fun getRemainingPagesToday(hasUnlimitedAccess: Boolean): Int {
        if (hasUnlimitedAccess) return Int.MAX_VALUE
        val todayKey = LocalDate.now().toString()
        if (prefs.getString("session_date", null) != todayKey) return FREE_TIER_MAX_PAGES_PER_DAY

        val pagesRead = prefs.getInt("pages_read_today", 0)
        return (FREE_TIER_MAX_PAGES_PER_DAY - pagesRead).coerceAtLeast(0)
    }
}
