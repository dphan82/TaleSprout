# TaleSprout — Android Studio Import Package

This archive contains the complete, aligned v3 source tree for **TaleSprout**, structured for direct import into Android Studio.

## How to Import into Android Studio
1. Extract `TaleSprout_AndroidStudio.zip` to a local folder (e.g., `C:\Projects\TaleSprout` or `~/Projects/TaleSprout`).
2. Open **Android Studio** -> **File** -> **Open...** and select the extracted `TaleSprout_AndroidStudio` root directory.
3. Android Studio will automatically download Gradle 8.9 and sync all dependencies (CameraX, Gemini GenAI SDK, ML Kit, Credential Manager, and Play Billing).
4. Click **Run** on a physical Android device with a rear camera (API 26+).
